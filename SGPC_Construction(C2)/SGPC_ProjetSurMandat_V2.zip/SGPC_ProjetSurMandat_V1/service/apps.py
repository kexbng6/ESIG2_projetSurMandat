from django.apps import AppConfig


class ServiceConfig(AppConfig):
    name = 'service'
