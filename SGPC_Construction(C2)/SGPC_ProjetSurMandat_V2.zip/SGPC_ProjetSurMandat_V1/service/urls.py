from django.conf.urls import url

from service import views

urlpatterns = [
    url(r'nos_services/',views.Services, name="nosServices"),

]
