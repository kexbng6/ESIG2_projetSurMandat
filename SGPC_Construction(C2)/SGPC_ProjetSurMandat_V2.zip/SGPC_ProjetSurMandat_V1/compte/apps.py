from django.apps import AppConfig


class CompteConfig(AppConfig):
    name = 'compte'
